<?php

class TestsConfig {
    const SELLER_ID = '';
    const SECRET_KEY = '';
    const SECRET_WORD = '';
}
