<?php
namespace Tco\Interfaces;

interface Auth{

    public function getHeaders();
}
