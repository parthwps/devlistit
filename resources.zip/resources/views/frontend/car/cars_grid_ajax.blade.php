 @if($car_contents->count() == 0)
                <div class="col-12" data-aos="fade-up"> <center> <h4>Sorry, No Posts Matched Your Criteria</h4> </center> </div>
            @else
            
            @php
                 $admin = App\Models\Admin::first();
            @endphp
            
            @foreach ($car_contents as $key => $car_content)

            @php
            
            $image_path = $car_content->feature_image;
            
            $rotation = 0;
            
            if($car_content->rotation_point > 0 )
            {
                 $rotation = $car_content->rotation_point;
            }
            
            if(!empty($image_path) && $car_content->rotation_point == 0 )
            {   
               $rotation = $car_content->galleries->where('image' , $image_path)->first();
               
               if($rotation == true)
               {
                    $rotation = $rotation->rotation_point;  
               }
               else
               {
                    $rotation = 0;   
               }
            }
            
            if(empty($car_content->feature_image))
            {
            $imng = $car_content->galleries->sortBy('priority')->first();
            
            $image_path = $imng->image;
            $rotation = $imng->rotation_point;
            }             
            @endphp
            
             @if ( $key == 6 || $key == 12 )
            
                <div class="widget-banner" style="margin-bottom: 1rem;">
                        @if (!empty(showAd(1)))
                            <div class="text-center">
                                {!! showAd(1) !!}
                            </div>
                        @endif
                        
                        @if (!empty(showAd(2)))
                            <div class="text-center">
                                {!! showAd(2) !!}
                            </div>
                        @endif
                </div>
            
            @endif
            
            <div class="col-xl-4 col-md-6" data-aos="fade-up">

            @if($car_content->is_featured == 1)
            <div class="product-default set_height border p-15 mb-25" data-id="{{$car_content->id}}" style="box-shadow: 0px 0px 10px #b3b3b3;border-radius: 10px;border: 5px solid #ff9e02 !important;">
            
            @else
            <div class="product-default set_height border p-15 mb-25" data-id="{{$car_content->id}}" style="box-shadow: 0px 0px 10px #b3b3b3;border-radius: 10px;">
            
            @endif
                    
            <figure class="product-img mb-15">
            <a href="{{ route('frontend.car.details', ['cattitle' => catslug($car_content->category_id),'slug' => $car_content->slug, 'id' => $car_content->id]) }}"
            class="lazy-container ratio ratio-2-3">
            <img class="lazyload"
            data-src="{{  $car_content->vendor->vendor_type == 'normal' ? asset('assets/admin/img/car-gallery/' .$image_path) :  env('SUBDOMAIN_APP_URL').'assets/admin/img/car-gallery/' . $image_path }}"
            alt="{{ optional($car_content)->title }}" style="transform: rotate({{$rotation}}deg);" >
            </a>

            @if($car_content->deposit_taken  == 1)
            <div class="reduce-tag">DEPOSIT TAKEN</div>
            @endif


            </figure>

              <div class="product-details" style="cursor:pointer;"  onclick="window.location='{{ route('frontend.car.details', ['cattitle' => catslug($car_content->category_id), 'slug' => $car_content->slug, 'id' => $car_content->id]) }}'" >
                
                  
                    <span class="product-category font-xsm">
                        
                           <h5 class="product-title mb-0">
                        <a href="{{ route('frontend.car.details', ['cattitle' => catslug($car_content->category_id),'slug' => $car_content->slug, 'id' => $car_content->id]) }}"
                          title="{{ optional($car_content)->title }}" class="us_grid_width">
                            {{ carBrand($car_content->brand_id) }}
                         {{ carModel($car_content->car_model_id) }} {{ optional($car_content)->title }}
                         </a>
                      </h5>
                      
                      
                        </span>
                        
                        <div class="d-flex align-items-center justify-content-between ">
                   
                      @if (Auth::guard('vendor')->check())
                        @php
                          $user_id = Auth::guard('vendor')->user()->id;
                          $checkWishList = checkWishList($car_content->id, $user_id);
                        @endphp
                      @else
                        @php
                          $checkWishList = false;
                        @endphp
                      @endif
                      
                        <a href="javascript:void(0);"
                        onclick="addToWishlist({{$car_content->id}})"
                        class="btn us_wishlist btn-icon "
                        data-tooltip="tooltip" data-bs-placement="right"
                        title="{{ $checkWishList == false ? __('Save Ad') : __('Saved') }}" style="position: absolute;
                        right: 0px;
                        bottom: 15%;
                        background:white;
                        color:red !important;
                        z-index: 10;
                        border: none;
                        color: white;
                        font-size: 25px;">
                        @if($checkWishList == false)
                            <i class="fal fa-heart"></i>
                        @else
                            <i class="fa fa-heart" aria-hidden="true"></i>
                        @endif
                      </a>
                     
                       <a href="javascript:void(0);"  class="us_grid_shared" onclick="openShareModal(this)" 
                        data-url="{{ route('frontend.car.details', ['cattitle' => catslug($car_content->category_id),'slug' => $car_content->slug, 'id' => $car_content->id]) }}"
                        style="background: transparent;
                        position: absolute;
                        right: 10px;
                        bottom: 5%;
                        z-index: 999;
                        border: none;
                        color: #1b87f4;
                        font-size: 25px;" ><i class="fa fa-share-alt" aria-hidden="true"></i>
                        </a>
                        
                        
                    </div>
                    <div class="author us_child_dv" style="cursor:pointer;" >
                     
                         <span style="line-height: 15px;font-size: 14px;"  onclick="window.location='{{ route('frontend.car.details', ['cattitle' => catslug($car_content->category_id), 'slug' => $car_content->slug, 'id' => $car_content->id]) }}'">
                             
                            @if($car_content->year)
                                {{ $car_content->year }} 
                             @endif
                             
                             @if($car_content->engineCapacity && $car_content->car_content->fuel_type )
                              <b class="us_dot"> - </b>   {{ roundEngineDisplacement($car_content) }} 
                             @endif
                             
                             @if($car_content->car_content->fuel_type )
                              <b class="us_dot"> - </b>   {{ $car_content->car_content->fuel_type->name }} 
                             @endif
                             
                             
                             @if($car_content->mileage)
                               <b class="us_dot"> - </b>    {{ number_format( $car_content->mileage ) }} mi 
                             @endif
                             
                             @if($car_content->created_at && $car_content->is_featured != 1)
                                <b class="us_dot"> - </b> {{calculate_datetime($car_content->created_at)}} 
                             @endif
                             
                             @if($car_content->city)
                                <b class="us_dot"> - </b> {{  Ucfirst($car_content->city) }} 
                             @endif
                               
                        </span>
                    
                    </div>
                    
                    @if(!$car_content->year && !$car_content->mileage && !$car_content->engineCapacity)
                    
                    <div style="display:flex;margin-top: 1.5rem;">
                        
                        <!--@if ($car_content->manager_special  == 1)-->
                        <!--<div class="price-tag" style="padding: 3px 10px;border-radius:5px; background:#25d366;font-size: 10px;" > Manage Special</div>-->
                        <!--@endif-->
                        
                        
                        <!--@if($car_content->is_sale == 1)-->
                        
                        <!--<div class="price-tag" style="padding: 3px 10px;border-radius:5px;margin-left: 10px;background: #434d89;font-size: 10px;" >  Sale </span></div>-->
                        
                        <!--@endif-->
                        
                        
                        <!--@if($car_content->reduce_price == 1)-->
                        
                        <!--<div class="price-tag" style="padding: 3px 10px;border-radius:5px;margin-left: 10px;background:#ff4444;font-size: 10px;" >    Reduced </span></div>-->
                        
                        <!--@endif-->
                    
                    </div>
                    
                    @endif 
                    
                     <ul class="product-icon-list  list-unstyled d-flex align-items-center us_absolute_position" style="margin-top: 10px;"  onclick="window.location='{{ route('frontend.car.details', ['cattitle' => catslug($car_content->category_id), 'slug' => $car_content->slug, 'id' => $car_content->id]) }}'"  >
                      
                        @if ($car_content->price != null)
                        <li class="icon-start us_price_icon" data-tooltip="tooltip" data-bs-placement="top"
                        title="Price">
                        <b style="color: gray;float: left;">Price</b>
                       
                        <strong  class="us_mrg" style="color: black;font-size: 20px;">
                        @if($car_content->previous_price && $car_content->previous_price < $car_content->price)
                        <strike style="font-weight: 300;color: red;font-size: 14px;margin-left: 15px;float: left;" class="us_mr_15">{{ symbolPrice($car_content->price) }}</strike> 
                        
                        <div> {{ symbolPrice($car_content->previous_price) }}</div>
                        @else
                        <strike style="font-weight: 300;color: white;font-size: 14px;    float: left;">  </strike> <div>  {{ symbolPrice($car_content->price) }}  </div> 
                        @endif
                        </strong>
                        </li>
                        @endif
                        
                        @if ($car_content->price != null && $car_content->price >= 1000)
                        <li class="icon-start" data-tooltip="tooltip" data-bs-placement="top"
                        title="">
                        <b style="color: gray;">From</b>
                       
                        <strong style="color: black;font-size: 20px;">
                        
                        {!! calulcateloanamount(!empty($car_content->previous_price && $car_content->previous_price < $car_content->price) ? $car_content->previous_price : $car_content->price)[0] !!}
                        
                        </strong>
                        </li>
                        @endif
                      
                    </ul>
                  
                  </div>
                </div><!-- product-default -->
              </div>
            @endforeach
            
             <div class="pagination us_pagination_filtered mb-40 justify-content-center" data-aos="fade-up">
            {{ $car_contents->links() }}
          </div>
          
          
          </div>
        
        </div>
        @endif