   
        <div class="col-12" data-aos="fade-up">
            <div class="section-title title-inline mb-30" data-aos="fade-up">
              <h2 class="title mb-20" >
                Recent Ads
              </h2>  
              <a href="ads?sort=new" style="text-decoration: none;color:#1D86F5;font-size:20px;">See All ></a>
            </div>
        </div> 
          
          
            @php
              $admin = App\Models\Admin::first();
            @endphp
            @foreach ($car_contents as $car_content)

             @php
            
            $image_path = $car_content->feature_image;
            
            $rotation = 0;
            
            if($car_content->rotation_point > 0 )
            {
                 $rotation = $car_content->rotation_point;
            }
            
            if(!empty($image_path) && $car_content->rotation_point == 0 )
            {   
               $rotation = $car_content->galleries->where('image' , $image_path)->first();
               
               if($rotation == true)
               {
                    $rotation = $rotation->rotation_point;  
               }
               else
               {
                    $rotation = 0;   
               }
            }
            
            if(empty($car_content->feature_image))
            {
            $imng = $car_content->galleries->sortBy('priority')->first();
            
            $image_path = $imng->image;
            $rotation = $imng->rotation_point;
            } 
           
            @endphp

           
            
            
        <div class="col-12 col-lg-3" data-aos="fade-up">
          @include('frontend/home/dataloader')
          <div class="product-default p-15 mb-25 loading-section font-type" style="padding: 0px !important;box-shadow: 0px 0px 20px 0px rgba(76, 87, 125, 0.1);border-color: transparent;border-radius: 10px;" data-id="{{$car_content->id}}">
            <figure class="product-img mb-15">
              <a href="{{ route('frontend.car.details', ['cattitle' => catslug($car_content->category_id),'slug' => $car_content->slug, 'id' => $car_content->id]) }}"
              class="lazy-container ratio ratio-2-3">
                <img class="lazyload"
                data-src="{{  $car_content->vendor->vendor_type == 'normal' ? asset('assets/admin/img/car-gallery/' .$image_path) :  env('SUBDOMAIN_APP_URL').'assets/admin/img/car-gallery/' . $image_path }}"
                alt="{{ optional($car_content)->title }}" style="transform: rotate({{$rotation}}deg);" >
              </a>

              @if (Auth::guard('vendor')->check())
                      @php
                        $user_id = Auth::guard('vendor')->user()->id;
                        $checkWishList = checkWishList($car_content->id, $user_id);
                      
                      @endphp
                    @else
                      @php
                        $checkWishList = false;
                      @endphp
              @endif
              <a href="javascript:void(0);" 
                onclick="addToWishlist({{$car_content->id}})" 
                class="btn btn-icon us_front_ad"
                data-tooltip="tooltip" 
                data-bs-placement="right"
                title="{{ $checkWishList == false ? __('Save Ad') : __('Saved') }}" 
                style="position: absolute; right: 10px; top: 10px; z-index: 999; background: white; border-radius: 10%; padding: 5px;">
                  @if($checkWishList == false)
                      <i class="fal fa-heart" style="color: blue;"></i>
                  @else
                      <i class="fa fa-heart" aria-hidden="true" style="color: blue;"></i>
                  @endif
              </a>
            </figure>
          
            <div class="product-detail m-4" style="padding-left: 0.5rem !important;">
              
                  <span class="product-category font-xsm">
                    <h5 class="product-title mb-0" style="display: inline-block;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;max-width: 210px;vertical-align: top;font-weight:bold" >
                      <a href="{{ route('frontend.car.details', ['cattitle' => catslug($car_content->category_id),'slug' => $car_content->slug, 'id' => $car_content->id]) }}"
                        title="{{ optional($car_content)->title }}">{{ carBrand($car_content->brand_id) }}
                       {{ carModel($car_content->car_model_id) }} {{ optional($car_content)->title }}</a>
                    </h5>    
                  </span>
                  <div class="d-flex align-items-center justify-content-between mt-3 mb-10" style="height: 10px;">
                    <div class="author">
                        @if ($car_content->vendor_id != 0)
                            <span>
                                {{ calculate_datetime($car_content->created_at) }} ago 
                            </span>
                        @endif
                    </div>

                    <a href="javascript:void(0);" onclick="openShareModal(this)" 
                      data-url="{{ route('frontend.car.details', ['cattitle' => catslug($car_content->category_id), 'slug' => $car_content->slug, 'id' => $car_content->id]) }}"
                      style="background: transparent; border: none; color: #1D86F5; font-size: 25px;">
                        <i class="fa fa-share-alt" aria-hidden="true"></i>
                    </a>
                  </div>

                <div class="d-flex align-items-center justify-content-between mt-4" style="height: 10px;font-size: 20px;font-weight:bold;">
                    <div class="author">
                        <span style="color: #1D86F5;">{{ symbolPrice($car_content->price) }}</span>
                    </div>
                    <div>
                        <!-- {!! calulcateloanamount(!empty($car_content->previous_price && $car_content->previous_price < $car_content->price) ? $car_content->previous_price : $car_content->price)[0] !!} -->
                        @php
                            // Get loan amount data
                            $loanAmount = calulcateloanamount(!empty($car_content->previous_price && $car_content->previous_price < $car_content->price) ? $car_content->previous_price : $car_content->price)[0];

                            // Remove span tags and replace p/w, p/m with 'week' and 'month'
                            $formattedLoanAmount = strip_tags($loanAmount);
                            $formattedLoanAmount = str_replace(['p/w', 'p/m'], ['week', 'month'], $formattedLoanAmount);

                            // Extract the number and the period (week/month) using regex or simple logic
                            preg_match('/(\d+)\s*\/?(week|month)/', $formattedLoanAmount, $matches);
                            $number = $matches[1] ?? ''; // The number (1, 2, etc.)
                            $period = $matches[2] ?? ''; // The period ('week' or 'month')
                        @endphp

                        {{-- Display with custom styles --}}
                        <span style="font-size: 18px; color: black;">
                            {{ symbolPrice($number) }}
                        </span>
                        <span style="font-size: 14px; color: gray;">
                            /{{ $period }}
                        </span>
                      </div>
                </div>
                

            </div>
          </div>
        </div>
        @endforeach

 
              
              
              
            