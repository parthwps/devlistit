</div></td></tr>
        <tr>  <td style="height:60px;">&nbsp;</td>
        </tr> <tr> <td style="text-align:center;">
              <a href="mailto:support@listit.im" title="logo" >
                support@listit.im
             </a></td></tr><tr>  <td style="text-align:center;">
              <p style="color:#455056; font-size:16px;line-height:24px; margin:0; font-family:'Rubik',sans-serif; ">
                   Simple, Safe, Secure 
                </p> </td> </tr> <tr><td style="text-align:center;">
                <p style="color:#455056; font-size:13px;line-height:24px; margin:0; font-family:'Rubik',sans-serif; font-weight: 500;">
                   Copyright ©2024. List It Ltd. - All Rights Reserved.
                </p></td></tr></td><tr><td style="height:20px;">&nbsp;</td></tr></table><tr><td style="height:20px;"></br></td>
                </tr></table></td></tr></table></body>